Don't copy my code, without my permission.
